import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.noor.quranprayer',
  appName: 'نور القرآن ومواقيت الصلاة',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
